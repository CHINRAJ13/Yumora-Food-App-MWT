import Order from "../models/Order.js";
import { sendEmail } from "../utils/email.js";
import { sendSMS } from "../utils/sms.js";

/**
 * @desc    Create a new order
 * @route   POST /api/orders
 */
export const createOrder = async (req, res) => {
  try {
    const { 
      items, 
      totalAmount, 
      userId, 
      address, 
      email, 
      phone, 
      paymentMethod,
      paymentId,
      paymentStatus
    } = req.body;

    // 1. Validation
    if (!items || items.length === 0) {
      return res.status(400).json({ message: "No items in order." });
    }

    // 2. Prepare Order Data
    const orderData = {
      userId: userId || "guest",
      items,
      totalAmount,
      address,
      paymentMethod: paymentMethod || "cod",
      paymentId,
      paymentStatus: paymentStatus || (paymentMethod === "cod" ? "COD" : "Pending"),
      email,
      phone,
      status: "Placed"
    };

    // 3. Save to MongoDB
    const order = new Order(orderData);
    await order.save();
    console.log(`✅ Order saved: ${order._id}`);

    // 4. Send Notifications (Async)
    const deliverTime = "35-45 mins";
    
    // Email Notification
    if (order.email) {
      const itemDetails = order.items.map(i => `• ${i.name} x ${i.quantity}`).join("\n");
      const emailText = `Your order #${order._id.toString().substring(0, 8)} has been placed!\n\nItems:\n${itemDetails}\n\nTotal: ₹${order.totalAmount}\nDelivery Address: ${order.address}\nEst. Delivery: ${deliverTime}\n\nThank you for choosing KovaiCrave!`;
      
      sendEmail(order.email, "Order Confirmed 🎉 - KovaiCrave", emailText)
        .catch(err => console.error("Email failed:", err.message));
    }

    // 📲 SEND SMS
    if (order.phone) {
      await sendSMS(
        order.phone,
        `🍔 Order Confirmed! Your order #${order._id} is placed successfully.`
      );
    }

    // 5. Success Response
    res.status(201).json({
      success: true,
      message: "Order placed successfully",
      order
    });

  } catch (error) {
    console.error("❌ Error in createOrder:", error.message);
    res.status(500).json({
      success: false,
      message: "Order placement failed",
      error: error.message
    });
  }
};

/**
 * @desc    Get all orders for a user
 * @route   GET /api/orders/:userId
 */
export const getUserOrders = async (req, res) => {
  try {
    const orders = await Order.find({ userId: req.params.userId }).sort({ createdAt: -1 });
    res.json(orders);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};

/**
 * @desc    Update order status
 * @route   PUT /api/orders/update/:id
 */
export const updateOrderStatus = async (req, res) => {
  try {
    const { id } = req.params;
    const { status } = req.body;

    const order = await Order.findByIdAndUpdate(
      id,
      { status },
      { new: true }
    );

    // 📲 SEND SMS
    if (order.phone) {
      await sendSMS(
        order.phone,
        `📦 Update: Your order is now ${status}`
      );
    }

    res.json(order);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};
