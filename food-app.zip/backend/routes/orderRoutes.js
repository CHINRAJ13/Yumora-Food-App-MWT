import express from "express";
import Order from "../models/Order.js";
import { sendEmail } from "../utils/email.js";
import * as orderController from "../controllers/orderController.js";

const router = express.Router();

// Helper to notify user via both channels (Used locally for simulation)
const notifyUser = async (order, message) => {
  if (order.email) await sendEmail(order.email, "KovaiCrave Order Update", message);
};

// --- Order Management ---

// Main order placement
router.post("/", orderController.createOrder);

// Alias /place for backward compatibility
router.post("/place", orderController.createOrder);

// Get user orders
router.get("/:userId", orderController.getUserOrders);

// Update order status
router.put("/update/:id", orderController.updateOrderStatus);

// Get specific order status
router.get("/:id/status", async (req, res) => {
  const order = await Order.findById(req.params.id);
  res.json(order);
});

// --- Simulation ---

// Simulate live tracking updates
router.post("/track/:id", async (req, res) => {
  const statuses = ["Preparing", "Out for Delivery", "Delivered"];
  
  let i = 0;
  
  const interval = setInterval(async () => {
    if (i >= statuses.length) {
      clearInterval(interval);
      return;
    }

    await Order.findByIdAndUpdate(req.params.id, {
      status: statuses[i]
    });
    
    console.log("📦 Status:", statuses[i]);
    
    i++;
  }, 5000); 

  res.json({ message: "Tracking started 🚚" });
});

export default router;
