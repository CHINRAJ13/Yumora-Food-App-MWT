import express from "express";
import User from "../models/User.js";
import jwt from "jsonwebtoken";
import dotenv from "dotenv";
import { sendSMS } from "../utils/sms.js";

dotenv.config();

const router = express.Router();
const JWT_SECRET = process.env.JWT_SECRET || "crave_secret_key_2024";

// 📲 SEND OTP — stored directly on User document
router.post("/send-otp", async (req, res) => {
  const { phone } = req.body;

  if (!phone) {
    return res.status(400).json({ success: false, message: "Phone number is required" });
  }

  const otp = Math.floor(100000 + Math.random() * 900000).toString(); // 6-digit OTP

  try {
    let user = await User.findOne({ phone });

    if (!user) {
      user = new User({ phone, name: "Guest User" });
    }

    user.otp = otp;
    user.otpExpires = new Date(Date.now() + 5 * 60 * 1000); // Expires in 5 min
    await user.save();

    // Send via SMS (falls back to console.log in dev mode)
    const result = await sendSMS(phone, `Your KovaiCrave verification code is: ${otp}. Valid for 5 minutes.`);

    console.log(`📲 OTP for ${phone}: ${otp}`); // Dev fallback

    res.json({
      success: result?.success || false,
      message: result?.simulated ? "OTP generated (Dev Mode: Check console)" : (result?.success ? "OTP sent via SMS" : "Failed to send SMS"),
      dev: result?.simulated
    });
  } catch (error) {
    console.error("OTP Error:", error);
    res.status(500).json({ success: false, message: "Failed to process OTP", error: error.message });
  }
});

// ✅ VERIFY OTP & Login/Register
router.post("/verify-otp", async (req, res) => {
  const { phone, otp } = req.body;

  try {
    const user = await User.findOne({ phone });

    if (!user || user.otp !== otp || !user.otpExpires || user.otpExpires < Date.now()) {
      return res.status(400).json({ success: false, message: "Invalid or expired OTP" });
    }

    // Clear OTP after successful verification
    user.otp = undefined;
    user.otpExpires = undefined;
    await user.save();

    const token = jwt.sign({ id: user._id, phone: user.phone }, JWT_SECRET, { expiresIn: "7d" });

    res.json({
      success: true,
      message: "Authentication successful",
      token,
      user
    });
  } catch (error) {
    console.error("Verification Error:", error);
    res.status(500).json({ success: false, message: "Verification failed", error: error.message });
  }
});

// 📝 Register (Email/Password)
router.post("/register", async (req, res) => {
  try {
    const user = new User(req.body);
    await user.save();
    res.json({ success: true, message: "User registered", user });
  } catch (error) {
    res.status(400).json({ success: false, message: error.message });
  }
});

// 🔑 Login (Email/Password)
router.post("/login", async (req, res) => {
  const { email, password } = req.body;

  try {
    const user = await User.findOne({ email });

    if (!user || user.password !== password) {
      return res.status(400).json({ success: false, message: "Invalid credentials" });
    }

    const token = jwt.sign({ id: user._id, phone: user.phone }, JWT_SECRET, { expiresIn: "7d" });

    res.json({ success: true, token, user });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
});

export default router;
