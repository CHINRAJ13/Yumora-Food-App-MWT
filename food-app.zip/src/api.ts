import axios from "axios";

const API = axios.create({
  baseURL: "/api",
  headers: {
    'Content-Type': 'application/json',
  },
});

// ✅ Request interceptor (JWT Auth)
API.interceptors.request.use(
  (config) => {
    const userInfo = localStorage.getItem('userInfo');
    if (userInfo) {
      try {
        const { token } = JSON.parse(userInfo);
        if (token) {
          config.headers.Authorization = `Bearer ${token}`;
        }
      } catch (err) {
        console.error('Error parsing user info', err);
      }
    }
    return config;
  },
  (error) => Promise.reject(error)
);

// ✅ Response interceptor (Auth error handling)
API.interceptors.response.use(
  (response) => response,
  (error) => {
    if (error.response?.status === 401) {
      if (!window.location.pathname.includes('/login')) {
        localStorage.removeItem('userInfo');
      }
    }
    return Promise.reject(error);
  }
);

export default API;

// --- Business Logic Methods ---

export const getRestaurants = async () => {
  const res = await API.get("/restaurants");
  return res.data;
};

export const getRestaurantById = async (id: string) => {
  const res = await API.get(`/restaurants/${id}`);
  return res.data;
};

export const getCategories = async () => {
  const res = await API.get("/categories");
  return res.data;
};

export const getBanners = async () => {
  const res = await API.get("/banners");
  return res.data;
};

export const loginUser = async (data: any) => {
  const res = await API.post('/auth/login', data);
  return res.data;
};

export const sendOtp = async (phone: string) => {
  const res = await API.post('/auth/send-otp', { phone });
  return res.data;
};

export const verifyOtp = async (phone: string, otp: string) => {
  const res = await API.post('/auth/verify-otp', { phone, otp });
  return res.data;
};

export const placeOrder = async (orderData: any) => {
  const res = await API.post('/orders', orderData);
  return res.data;
};

export const getOrders = async (userId: string) => {
  const res = await API.get(`/orders/${userId}`);
  return res.data;
};

export const getOrderStatus = async (orderId: string) => {
  const res = await API.get(`/orders/${orderId}/status`);
  return res.data;
};
