import { useEffect, useState } from "react";
import { Navigate, useLocation } from "react-router-dom";

export const ProtectedRoute = ({ children }: { children: React.ReactNode }) => {
  const [isAuthenticated, setIsAuthenticated] = useState<boolean | null>(null);
  const location = useLocation();

  useEffect(() => {
    // Check if userInfo exists in localStorage
    const userInfo = localStorage.getItem("userInfo");
    setIsAuthenticated(!!userInfo);
  }, []);

  if (isAuthenticated === null) {
    return <div className="min-h-screen bg-background flex items-center justify-center font-bold font-mono animate-pulse">Verifying Session...</div>;
  }

  if (!isAuthenticated) {
    // Pass the attempted URL so we standardise deep linking auth redirects
    return <Navigate to="/login" state={{ from: location.pathname + location.search }} replace />;
  }

  return <>{children}</>;
};
