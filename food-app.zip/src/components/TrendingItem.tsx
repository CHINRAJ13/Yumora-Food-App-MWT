import { Star } from "lucide-react";
import { motion } from "framer-motion";
import { MenuItem } from "@/data/mockData";
import { useCart } from "@/context/CartContext";

interface TrendingItemProps {
  item: MenuItem;
  restaurantId: string;
  restaurantName: string;
  index: number;
}

const TrendingItem = ({ item, restaurantId, restaurantName, index }: TrendingItemProps) => {
  const { addItem } = useCart();

  return (
    <motion.div
      initial={{ opacity: 0, scale: 0.95 }}
      whileInView={{ opacity: 1, scale: 1 }}
      viewport={{ once: true }}
      transition={{ delay: index * 0.05 }}
      className="group relative min-w-[160px] sm:min-w-[180px] shrink-0"
    >
      <div className="relative w-full h-56 overflow-hidden rounded-xl bg-cover bg-center transition-all duration-500">
        <img
          src={item.image}
          alt={item.name}
          className="w-full h-full object-cover transition-all duration-500 group-hover:scale-105"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-black/70 via-black/30 to-transparent" />
        <div className="absolute bottom-0 left-0 right-0 p-3">
          <p className="text-primary-foreground text-sm font-bold truncate">{item.name}</p>
          <p className="text-primary-foreground/70 text-[10px] truncate">{restaurantName}</p>
          <div className="flex items-center justify-between mt-1.5">
            <span className="text-primary-foreground font-bold text-sm">₹{item.price}</span>
            {item.rating && (
              <span className="flex items-center gap-0.5 text-[10px] text-warning font-semibold">
                <Star className="w-2.5 h-2.5 fill-current" /> {item.rating}
              </span>
            )}
          </div>
        </div>
      </div>
      <motion.button
        whileTap={{ scale: 0.9 }}
        onClick={() => addItem(item, restaurantId, restaurantName)}
        className="absolute -bottom-3 right-3 bg-card text-primary text-xs font-bold px-3 py-1.5 rounded-lg shadow-elevated border border-primary/20 hover:gradient-primary hover:text-primary-foreground transition-all"
      >
        ADD
      </motion.button>
    </motion.div>
  );
};

export default TrendingItem;
