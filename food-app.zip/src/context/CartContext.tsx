import React, { createContext, useContext, useState, useCallback, useEffect } from "react";
import { CartItem, MenuItem, Order } from "@/data/mockData";
import { toast } from "sonner";
import api from "@/api";

interface CartContextType {
  items: CartItem[];
  addItem: (item: MenuItem, restaurantId: string, restaurantName: string) => void;
  removeItem: (itemId: string) => void;
  updateQuantity: (itemId: string, quantity: number) => void;
  clearCart: () => void;
  totalItems: number;
  totalPrice: number;
  coupon: string | null;
  applyCoupon: (code: string) => void;
  removeCoupon: () => void;
  discount: number;
  orders: Order[];
  reorderItems: (itemsToReorder: any[], restaurantId: string, restaurantName: string) => void;
  loading: boolean;
  error: string | null;
  fetchOrders: () => Promise<void>;
}

const CartContext = createContext<CartContextType | undefined>(undefined);

const COUPONS: Record<string, { type: "percent" | "flat"; value: number }> = {
  KOVAI100: { type: "flat", value: 100 },
  FLAT50: { type: "percent", value: 50 },
  FREEDEL: { type: "flat", value: 0 },
  UPISAVE: { type: "flat", value: 75 },
  SAVE20: { type: "percent", value: 20 },
};

export const CartProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [items, setItems] = useState<CartItem[]>([]);
  const [coupon, setCoupon] = useState<string | null>(null);
  const [orders, setOrders] = useState<Order[]>([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  // Fetch orders from backend
  const fetchOrders = useCallback(async () => {
    const userInfoStr = localStorage.getItem("userInfo");
    const userInfo = userInfoStr ? JSON.parse(userInfoStr) : null;
    if (!userInfo) return;

    setLoading(true);
    setError(null);
    try {
      const { data } = await api.get(`/orders/${userInfo.user._id}`);
      // Map backend orders to frontend Order interface
      const mappedOrders = data.map((o: any) => ({
        id: o._id,
        items: o.items,
        total: o.totalAmount,
        status: o.status,
        date: new Date(o.createdAt).toLocaleString("en-IN"),
        restaurantName: o.restaurantName,
        paymentMethod: o.paymentMethod,
        address: o.address,
      }));
      setOrders(mappedOrders);
    } catch (error: any) {
      console.error("Error fetching orders:", error);
      setError("Failed to sync your orders. Please refresh.");
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    fetchOrders();
  }, [fetchOrders]);

  const addItem = useCallback((item: MenuItem, restaurantId: string, restaurantName: string) => {
    setItems((prev) => {
      // Use _id for backend-sourced restaurants, id for mock data
      const currentRestaurantId = restaurantId;
      if (prev.length > 0 && prev[0].restaurantId !== currentRestaurantId) {
        toast.error("Your cart has items from another restaurant. Clear cart first.");
        return prev;
      }
      const itemId = item.id; // Still use .id from the MenuItem object
      const existing = prev.find((i) => i.id === itemId);
      if (existing) {
        return prev.map((i) => (i.id === itemId ? { ...i, quantity: i.quantity + 1 } : i));
      }
      return [...prev, { ...item, quantity: 1, restaurantId: currentRestaurantId, restaurantName }];
    });
    toast.success(`${item.name} added to cart`);
  }, []);

  const removeItem = useCallback((itemId: string) => {
    setItems((prev) => prev.filter((i) => i.id !== itemId));
  }, []);

  const updateQuantity = useCallback((itemId: string, quantity: number) => {
    if (quantity <= 0) {
      setItems((prev) => prev.filter((i) => i.id !== itemId));
      return;
    }
    setItems((prev) => prev.map((i) => (i.id === itemId ? { ...i, quantity } : i)));
  }, []);

  const clearCart = useCallback(() => {
    setItems([]);
    setCoupon(null);
  }, []);

  const totalItems = items.reduce((sum, i) => sum + i.quantity, 0);
  const totalPrice = items.reduce((sum, i) => sum + i.price * i.quantity, 0);

  const discount = coupon && COUPONS[coupon]
    ? COUPONS[coupon].type === "percent"
      ? Math.round(totalPrice * COUPONS[coupon].value / 100)
      : Math.min(COUPONS[coupon].value, totalPrice)
    : 0;

  const applyCoupon = useCallback((code: string) => {
    const upper = code.toUpperCase().trim();
    if (COUPONS[upper]) {
      setCoupon(upper);
      toast.success(`Coupon ${upper} applied!`);
    } else {
      toast.error("Invalid coupon code");
    }
  }, []);

  const removeCoupon = useCallback(() => {
    setCoupon(null);
    toast("Coupon removed");
  }, []);

  const reorderItems = useCallback((itemsToReorder: any[], restaurantId: string, restaurantName: string) => {
    setItems([]); // Clear current cart
    const formattedItems = itemsToReorder.map(item => ({
      ...item,
      id: item._id || item.id,
      restaurantId,
      restaurantName
    }));
    setItems(formattedItems);
    toast.success("Items added back to cart!");
  }, []);

  const placeOrder = useCallback(async (paymentMethod: string, address: string, email: string, phone: string, paymentDetails?: any) => {
    setLoading(true);
    try {
      const deliveryFee = totalPrice > 199 ? 0 : 30;
      const taxes = Math.round(totalPrice * 0.05);
      const finalTotal = Math.round(totalPrice - discount + deliveryFee + taxes);
      
      const userInfoStr = localStorage.getItem("userInfo");
      const userInfo = userInfoStr ? JSON.parse(userInfoStr) : null;
      
      const orderData = {
        userId: userInfo?.user?._id || "guest",
        email: email || userInfo?.user?.email,
        phone: phone || userInfo?.user?.phone,
        items: items.map(item => ({
          name: item.name,
          quantity: item.quantity,
          price: item.price,
          image: item.image,
          isVeg: item.isVeg,
          restaurantId: item.restaurantId
        })),
        totalAmount: finalTotal,
        paymentMethod,
        paymentId: paymentDetails?.paymentId,
        paymentStatus: paymentDetails?.paymentStatus || (paymentMethod === "cod" ? "COD" : "Pending"),
        address,
        restaurantName: items[0]?.restaurantName || "Unknown Restaurant"
      };

      const { data } = await api.post("/orders", orderData);
      
      // Start tracking simulation automatically 🚚
      if (data.order?._id) {
        api.post(`/orders/simulate/${data.order._id}`).catch(err => console.error("Simulation error", err));
      }
      
      await fetchOrders(); 
      setItems([]);
      setCoupon(null);
      toast.success("Order Placed Successfully!");
      return data.order?._id || data._id;
    } catch (error: any) {
      toast.error(error.response?.data?.message || "Failed to place order");
      return null;
    } finally {
      setLoading(false);
    }
  }, [items, totalPrice, discount, fetchOrders]);

  return (
    <CartContext.Provider value={{
      items, addItem, removeItem, updateQuantity, clearCart,
      totalItems, totalPrice, coupon, applyCoupon, removeCoupon,
      discount, orders, placeOrder, loading, error, fetchOrders
    }}>
      {children}
    </CartContext.Provider>
  );
};

export const useCart = () => {
  const ctx = useContext(CartContext);
  if (!ctx) throw new Error("useCart must be used within CartProvider");
  return ctx;
};
