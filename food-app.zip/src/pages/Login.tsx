import { useState } from "react";
import { useNavigate, useLocation } from "react-router-dom";
import api, { loginUser, sendOtp, verifyOtp } from "@/api";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { toast } from "@/hooks/use-toast";
import { Eye, EyeOff, Mail, Lock, User, Phone, MapPin } from "lucide-react";
import OTPInput from "@/components/OTPInput";
import { motion } from "framer-motion";

const Login = () => {
  const navigate = useNavigate();
  const location = useLocation();
  const [loading, setLoading] = useState(false);
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [confirmPassword, setConfirmPassword] = useState("");
  const [showPassword, setShowPassword] = useState(false);
  const [phoneNumber, setPhoneNumber] = useState("");
  const [fullName, setFullName] = useState("");
  const [address, setAddress] = useState("");
  const [isOtpSent, setIsOtpSent] = useState(false);
  const [otp, setOtp] = useState("");
  const [otpLoading, setOtpLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setError(null);
    try {
      const res = await loginUser({ email, password });
      localStorage.setItem("token", res.token);
      localStorage.setItem("userInfo", JSON.stringify(res));

      toast({ title: "Login successful", description: "Welcome back!" });
      const returnUrl = location.state?.from || "/";
      navigate(returnUrl);
    } catch (err: any) {
      const msg = err.response?.data?.message || err.message;
      setError(msg);
      toast({
        title: "Login failed",
        description: msg,
        variant: "destructive",
      });
    } finally {
      setLoading(false);
    }
  };

  const handleSignup = async (e: React.FormEvent) => {
    e.preventDefault();
    if (password !== confirmPassword) {
      setError("Passwords don't match");
      toast({ title: "Passwords don't match", variant: "destructive" });
      return;
    }
    setLoading(true);
    setError(null);
    try {
      const { data } = await api.post("/auth/register", {
        fullName,
        email,
        password,
        phone: phoneNumber,
        address,
      });

      localStorage.setItem("userInfo", JSON.stringify(data));
      toast({ title: "Signup successful", description: "Welcome to KovaiCrave!" });
      navigate("/");
    } catch (err: any) {
      const msg = err.response?.data?.message || err.message;
      setError(msg);
      toast({
        title: "Signup failed",
        description: msg,
        variant: "destructive",
      });
    } finally {
      setLoading(false);
    }
  };

  const handleSendOtp = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!phoneNumber) {
      toast({ title: "Phone number required", variant: "destructive" });
      return;
    }
    setOtpLoading(true);
    try {
      await sendOtp(phoneNumber);
      setIsOtpSent(true);
      toast({ title: "OTP Sent", description: "Please check your messages." });
    } catch (error: any) {
      toast({ title: "Error", description: error.message, variant: "destructive" });
    } finally {
      setOtpLoading(false);
    }
  };

  const handleVerifyOtp = async (finalOtp?: string) => {
    const code = finalOtp || otp;
    if (code.length < 6) return;

    setOtpLoading(true);
    try {
      const res = await verifyOtp(phoneNumber, code);
      
      localStorage.setItem("token", res.token);
      localStorage.setItem("userInfo", JSON.stringify(res));

      toast({ title: "Authentication successful", description: `Welcome back, ${res.user.name}!` });
      const returnUrl = location.state?.from || "/";
      navigate(returnUrl);
    } catch (error: any) {
      toast({
        title: "Verification failed",
        description: error.response?.data?.message || "Invalid OTP code",
        variant: "destructive",
      });
    } finally {
      setOtpLoading(false);
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-[url('https://images.unsplash.com/photo-1504674900247-0877df9cc836?q=80&w=2070')] bg-cover bg-center py-12 px-4 relative">
      <div className="absolute inset-0 bg-black/40 backdrop-blur-[2px]" />
      
      <motion.div 
        initial={{ opacity: 0, scale: 0.9 }}
        animate={{ opacity: 1, scale: 1 }}
        className="w-full max-w-md space-y-4 relative z-10"
      >
        {/* Header */}
        <div className="text-center space-y-2 mb-6">
          <div className="inline-flex items-center justify-center w-14 h-14 rounded-2xl gradient-primary shadow-2xl">
            <span className="text-white font-black text-2xl">K</span>
          </div>
          <h1 className="text-4xl font-black text-white drop-shadow-lg">KovaiCrave</h1>
          <p className="text-white/80 text-sm font-medium">Coimbatore's Premium Food Delivery</p>
        </div>

        <Card className="bg-white/80 backdrop-blur-xl border-white/20 shadow-2xl rounded-3xl overflow-hidden">
          <CardHeader className="pb-2">
            <CardTitle className="text-2xl font-black text-center text-gray-900">Welcome</CardTitle>
            <CardDescription className="text-center font-medium text-gray-600">
              Pick your preferred login method
            </CardDescription>
            {error && (
              <motion.div 
                initial={{ opacity: 0, y: -10 }}
                animate={{ opacity: 1, y: 0 }}
                className="mt-4 p-3 bg-red-50 text-red-600 text-xs font-bold rounded-xl border border-red-100 flex items-center gap-2"
              >
                <span className="w-1.5 h-1.5 rounded-full bg-red-500 animate-pulse shrink-0" />
                {error}
              </motion.div>
            )}
          </CardHeader>
          <CardContent>
            <Tabs defaultValue="otp" className="w-full">
              <TabsList className="grid w-full grid-cols-3 bg-gray-100/50 p-1 rounded-2xl h-12">
                <TabsTrigger value="otp" className="rounded-xl font-bold data-[state=active]:bg-white data-[state=active]:shadow-sm">Phone</TabsTrigger>
                <TabsTrigger value="login" className="rounded-xl font-bold data-[state=active]:bg-white data-[state=active]:shadow-sm">Email</TabsTrigger>
                <TabsTrigger value="signup" className="rounded-xl font-bold data-[state=active]:bg-white data-[state=active]:shadow-sm">Join</TabsTrigger>
              </TabsList>

              {/* Phone OTP Tab */}
              <TabsContent value="otp" className="space-y-6 mt-6">
                {!isOtpSent ? (
                  <form onSubmit={handleSendOtp} className="space-y-4">
                    <div className="space-y-2">
                      <Label htmlFor="otp-phone" className="text-xs font-bold uppercase tracking-wider text-gray-500 ml-1">Phone Number</Label>
                      <div className="relative">
                        <Phone className="absolute left-4 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
                        <Input
                          id="otp-phone"
                          type="tel"
                          placeholder="Enter your 10-digit number"
                          value={phoneNumber}
                          onChange={(e) => setPhoneNumber(e.target.value)}
                          required
                          className="h-12 pl-12 bg-white/50 border-white/20 rounded-xl font-medium focus:ring-primary/20"
                        />
                      </div>
                    </div>
                    <Button type="submit" className="w-full h-12 rounded-xl gradient-primary font-bold text-lg shadow-lg" disabled={otpLoading}>
                      {otpLoading ? "Sending Code..." : "Send Verification Code"}
                    </Button>
                  </form>
                ) : (
                  <div className="space-y-6 text-center">
                    <div className="space-y-2">
                      <Label className="text-xs font-bold uppercase tracking-wider text-gray-500">Enter 6-Digit Code</Label>
                      <OTPInput 
                        onComplete={(code) => {
                          setOtp(code);
                          handleVerifyOtp(code);
                        }} 
                        disabled={otpLoading} 
                      />
                      <p className="text-xs text-gray-500 mt-4">Code sent to <span className="font-bold">{phoneNumber}</span></p>
                    </div>
                    
                    <div className="flex flex-col gap-3">
                      <Button 
                        onClick={() => handleVerifyOtp()} 
                        className="w-full h-12 rounded-xl gradient-primary font-bold text-lg shadow-lg" 
                        disabled={otpLoading || otp.length < 6}
                      >
                        {otpLoading ? "Verifying..." : "Verify & Sign In"}
                      </Button>
                      <button 
                        type="button" 
                        onClick={() => setIsOtpSent(false)}
                        className="text-sm font-bold text-primary hover:underline"
                      >
                        Try different number
                      </button>
                    </div>
                  </div>
                )}
              </TabsContent>

              {/* Login Tab */}
              <TabsContent value="login" className="space-y-4 mt-6">
                <form onSubmit={handleLogin} className="space-y-4">
                  <div className="space-y-2">
                    <Label htmlFor="email" className="text-xs font-bold uppercase tracking-wider text-gray-500 ml-1">Email</Label>
                    <div className="relative">
                      <Mail className="absolute left-4 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
                      <Input
                        id="email"
                        type="email"
                        placeholder="your@email.com"
                        value={email}
                        onChange={(e) => setEmail(e.target.value)}
                        required
                        className="h-12 pl-12 bg-white/50 border-white/20 rounded-xl"
                      />
                    </div>
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="password" className="text-xs font-bold uppercase tracking-wider text-gray-500 ml-1">Password</Label>
                    <div className="relative">
                      <Lock className="absolute left-4 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
                      <Input
                        id="password"
                        type={showPassword ? "text" : "password"}
                        placeholder="••••••••"
                        value={password}
                        onChange={(e) => setPassword(e.target.value)}
                        required
                        className="h-12 pl-12 pr-12 bg-white/50 border-white/20 rounded-xl"
                      />
                      <button
                        type="button"
                        onClick={() => setShowPassword(!showPassword)}
                        className="absolute right-4 top-1/2 -translate-y-1/2 text-gray-400 hover:text-gray-900"
                      >
                        {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                      </button>
                    </div>
                  </div>
                  <Button type="submit" className="w-full h-12 rounded-xl gradient-primary font-bold shadow-lg" disabled={loading}>
                    {loading ? "Signing in..." : "Sign In"}
                  </Button>
                </form>
              </TabsContent>

              {/* Signup Tab */}
              <TabsContent value="signup" className="space-y-4 mt-6">
                <form onSubmit={handleSignup} className="space-y-4">
                  <div className="grid grid-cols-2 gap-3">
                    <div className="space-y-2">
                       <Label className="text-[10px] font-bold uppercase text-gray-500 ml-1">Full Name</Label>
                       <Input value={fullName} onChange={(e) => setFullName(e.target.value)} placeholder="Name" required className="h-10 bg-white/50 rounded-xl" />
                    </div>
                    <div className="space-y-2">
                       <Label className="text-[10px] font-bold uppercase text-gray-500 ml-1">Phone</Label>
                       <Input value={phoneNumber} onChange={(e) => setPhoneNumber(e.target.value)} placeholder="Phone" required className="h-10 bg-white/50 rounded-xl" />
                    </div>
                  </div>
                  <div className="space-y-2">
                    <Label className="text-[10px] font-bold uppercase text-gray-500 ml-1">Email</Label>
                    <Input type="email" value={email} onChange={(e) => setEmail(e.target.value)} placeholder="Email" required className="h-10 bg-white/50 rounded-xl" />
                  </div>
                  <div className="space-y-2">
                    <Label className="text-[10px] font-bold uppercase text-gray-500 ml-1">Password</Label>
                    <Input type="password" value={password} onChange={(e) => setPassword(e.target.value)} placeholder="Min 6 chars" required className="h-10 bg-white/50 rounded-xl" />
                  </div>
                  <div className="space-y-2">
                    <Label className="text-[10px] font-bold uppercase text-gray-500 ml-1">Confirm Password</Label>
                    <Input type="password" value={confirmPassword} onChange={(e) => setConfirmPassword(e.target.value)} placeholder="Repeat password" required className="h-10 bg-white/50 rounded-xl" />
                  </div>
                  <Button type="submit" className="w-full h-11 rounded-xl gradient-primary font-bold shadow-md" disabled={loading}>
                    Create Premium Account
                  </Button>
                </form>
              </TabsContent>
            </Tabs>
          </CardContent>
        </Card>

        {/* Footer */}
        <p className="text-xs text-center text-white/60 font-medium">
          Secure, Encrypted, and lightning fast. ⚡
        </p>
      </motion.div>
    </div>
  );
};

export default Login;