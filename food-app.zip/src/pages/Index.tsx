import { useState, useMemo, useEffect } from "react";
import { Link, useSearchParams } from "react-router-dom";
import { Search, ArrowRight, ChevronLeft, ChevronRight, TrendingUp, Zap, Store, Utensils, Star, RefreshCw } from "lucide-react";
import { motion, AnimatePresence } from "framer-motion";
import api, { getRestaurants, getCategories, getBanners } from "@/api";
import RestaurantCard from "@/components/RestaurantCard";
import CategoryChip from "@/components/CategoryChip";
import { Skeleton } from "@/components/ui/skeleton";
import AnimatedCounter from "@/components/AnimatedCounter";
import TrendingItem from "@/components/TrendingItem";
import Navbar from "@/components/Navbar";
import Footer from "@/components/Footer";

const Index = () => {
  const [restaurants, setRestaurants] = useState([]);
  const [categories, setCategories] = useState([]);
  const [banners, setBanners] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [activeCategory, setActiveCategory] = useState<string | null>(null);
  const [bannerIndex, setBannerIndex] = useState(0);
  const [searchQuery, setSearchQuery] = useState("");
  const [vegOnly, setVegOnly] = useState(false);
  const [nonVegOnly, setNonVegOnly] = useState(false);
  const [searchParams] = useSearchParams();

  // Fetch data from API
  const fetchData = async () => {
    setLoading(true);
    setError(null);
    try {
      const [restaurantsData, categoriesData, bannersData] = await Promise.all([
        getRestaurants(),
        getCategories(),
        getBanners()
      ]);
      console.log("Restaurants data from API:", restaurantsData);
      setRestaurants(restaurantsData || []);
      setCategories(categoriesData || []);
      setBanners(bannersData || []);
    } catch (error) {
      console.error("Error fetching data:", error);
      setError("Failed to load content. Please check your connection.");
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchData();
  }, []);

  // Deep link item search
  useEffect(() => {
    const item = searchParams.get("item");
    if (item) {
      setSearchQuery(item);
    }
  }, [searchParams]);

  // Auto-rotate banners
  useEffect(() => {
    if (banners.length === 0) return;
    const timer = setInterval(() => {
      setBannerIndex((i) => (i + 1) % banners.length);
    }, 4000);
    return () => clearInterval(timer);
  }, [banners.length]);

  const filteredRestaurants = useMemo(() => {
    let list = [...restaurants];
    if (vegOnly) list = list.filter((r) => r.isVeg);
    if (nonVegOnly) list = list.filter((r) => !r.isVeg);
    if (activeCategory) {
      list = list.filter((r) =>
        r.cuisines.some((c) => c.toLowerCase().includes(activeCategory.toLowerCase())) ||
        r.menu.some((m) => m.category.toLowerCase().includes(activeCategory.toLowerCase()))
      );
    }
    if (searchQuery.trim()) {
      const q = searchQuery.toLowerCase();
      list = list.filter(
        (r) =>
          r.name.toLowerCase().includes(q) ||
          r.cuisines.some((c) => c.toLowerCase().includes(q)) ||
          r.menu.some((m) => m.name.toLowerCase().includes(q))
      );
    }
    return list;
  }, [restaurants, activeCategory, searchQuery, vegOnly, nonVegOnly]);

  // Get trending items (bestsellers across restaurants)
  const trendingItems = useMemo(() => {
    return restaurants.flatMap((r) =>
      r.menu
        .filter((m: any) => m.isBestseller)
        .map((m: any) => ({ item: m, restaurantId: r.id, restaurantName: r.name }))
    ).slice(0, 10);
  }, [restaurants]);

  return (
    <div className="min-h-screen bg-background pb-20 lg:pb-0">
      <Navbar />

      {/* Hero */}
      <section className="relative min-h-[calc(100vh-4rem)] flex items-center pt-6 pb-12 sm:pt-10 sm:pb-20 overflow-hidden bg-gradient-to-b from-orange-50/50 to-white">
        {/* Dynamic Background Elements */}
        <div className="absolute top-0 right-0 -mr-20 -mt-20 w-[500px] h-[500px] bg-amber-400/20 rounded-full blur-[100px] animate-pulse" />
        <div className="absolute bottom-0 left-0 -ml-20 -mb-20 w-[600px] h-[600px] bg-red-500/10 rounded-full blur-[120px]" style={{ animationDuration: '4s' }} />
        <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[800px] h-[800px] bg-orange-400/5 rounded-full blur-[100px]" />
        
        <div className="container mx-auto px-4 relative z-10 w-full max-w-7xl">
          <div className="flex flex-col lg:flex-row items-center gap-12 sm:gap-16 lg:gap-8">
            
            {/* Left Content */}
            <motion.div
              initial={{ opacity: 0, x: -30 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.6 }}
              className="lg:w-1/2 flex flex-col items-center lg:items-start text-center lg:text-left pt-6 sm:pt-10 lg:pt-0 w-full"
            >
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.2 }}
                className="inline-flex items-center gap-2 bg-white/80 text-gray-800 text-[11px] sm:text-xs font-black px-4 py-2 rounded-full mb-6 border border-white/40 shadow-sm uppercase tracking-[0.2em]"
              >
                <div className="flex bg-orange-100 p-1.5 rounded-full">
                  <Star className="w-3.5 h-3.5 text-orange-500 fill-current animate-pulse" />
                </div>
                Premium Delivery in Coimbatore
              </motion.div>
              
              <h1 className="text-5xl sm:text-6xl lg:text-8xl font-black text-gray-900 tracking-tight leading-[1.05] mb-6">
                Crave it. <br/>
                <span className="text-orange-600 italic">Pro</span> Mode.
              </h1>
              
              <p className="text-lg sm:text-xl text-gray-600 mb-8 max-w-lg leading-relaxed font-medium">
                Experience culinary perfection from Coimbatore's finest. Delivered with absolute precision and speed.
              </p>

              {/* Search Box - Premium */}
              <div className="w-full max-w-xl relative group mb-10">
                <div className="absolute -inset-1 bg-gradient-to-r from-orange-500 to-red-500 rounded-2xl blur opacity-10 group-focus-within:opacity-25 transition duration-500"></div>
                <div className="relative flex items-center w-full bg-white rounded-2xl shadow-2xl shadow-gray-200/50 overflow-hidden p-2 border border-gray-100">
                  <div className="pl-4">
                    <Search className="w-6 h-6 text-gray-400 group-focus-within:text-orange-500 transition-colors" />
                  </div>
                  <input
                    type="text"
                    placeholder="Search for restaurants, cuisines..."
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    className="w-full pl-3 pr-4 py-4 bg-transparent text-lg outline-none text-gray-900 placeholder:text-gray-400 font-bold"
                  />
                  <button className="bg-orange-600 text-white px-8 py-4 rounded-xl text-base font-black hover:bg-orange-700 transition-all shadow-lg hover:shadow-orange-200 active:scale-95 whitespace-nowrap uppercase tracking-widest">
                    Search
                  </button>
                </div>
              </div>

              <div className="flex gap-6 items-center">
                <div className="flex -space-x-3">
                  {[10, 11, 12, 13].map((img, i) => (
                    <div key={i} className="w-10 h-10 rounded-full border-2 border-white overflow-hidden bg-gray-100">
                      <img src={`https://i.pravatar.cc/100?img=${img}`} alt="User" />
                    </div>
                  ))}
                  <div className="w-10 h-10 rounded-full border-2 border-white bg-orange-100 flex items-center justify-center text-[10px] font-black text-orange-600 tracking-tighter">
                    50+
                  </div>
                </div>
                <div className="text-left">
                  <div className="flex items-center gap-1 text-orange-500 mb-0.5">
                    {[1, 2, 3, 4, 5].map((i) => (
                      <Star key={i} className="w-3 h-3 fill-current" />
                    ))}
                  </div>
                  <p className="text-[10px] font-black text-gray-400 uppercase tracking-widest">Coimbatore's Favorite</p>
                </div>
              </div>
            </motion.div>

            {/* Right Content - Visual */}
            <motion.div
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ duration: 0.6, delay: 0.1 }}
              className="lg:w-1/2 relative flex justify-center mt-10 lg:mt-0 w-full"
            >
              <div className="relative w-full max-w-lg lg:w-[500px]">
                {/* Main Visual Stack */}
                <div className="relative z-10 w-full h-[450px] lg:h-[550px]">
                  <div className="relative w-full h-full rounded-[3.5rem] overflow-hidden shadow-2xl border-8 border-white bg-white bg-cover bg-center group transition-all duration-500 hover:scale-105">
                    <img 
                      src="https://images.unsplash.com/photo-1546069901-ba9599a7e63c?q=80&w=2000" 
                      alt="Delicious Food" 
                      className="w-full h-full object-cover transition-all duration-500 group-hover:scale-110"
                    />
                    <div className="absolute inset-0 bg-gradient-to-t from-black/70 via-black/30 to-transparent" />
                  </div>

                  {/* Floating Badges - Pro Style */}
                  <motion.div 
                    animate={{ y: [0, -15, 0] }}
                    transition={{ duration: 4, repeat: Infinity, ease: "easeInOut" }}
                    className="absolute -top-6 -right-6 lg:-right-10 bg-white/90 backdrop-blur-xl rounded-3xl p-5 shadow-2xl border border-white flex items-center gap-4 z-20"
                  >
                    <div className="w-12 h-12 bg-orange-600 rounded-2xl flex items-center justify-center text-white shadow-lg shadow-orange-200">
                      <Zap className="w-6 h-6 fill-current" />
                    </div>
                    <div>
                      <p className="text-[10px] font-black text-gray-400 uppercase tracking-widest">Instant</p>
                      <p className="text-lg font-black text-gray-900 leading-tight">Delivery</p>
                    </div>
                  </motion.div>
                  
                  <motion.div 
                    animate={{ y: [0, 15, 0] }}
                    transition={{ duration: 5, repeat: Infinity, ease: "easeInOut", delay: 1 }}
                    className="absolute -bottom-6 -left-6 lg:-left-10 bg-white/90 backdrop-blur-xl rounded-3xl p-5 shadow-2xl border border-white flex items-center gap-4 z-20"
                  >
                    <div className="w-12 h-12 bg-green-600 rounded-2xl flex items-center justify-center text-white shadow-lg shadow-green-200">
                      <Store className="w-6 h-6" />
                    </div>
                    <div>
                      <p className="text-[10px] font-black text-gray-400 uppercase tracking-widest">Verified</p>
                      <p className="text-lg font-black text-gray-900 leading-tight">50+ Restos</p>
                    </div>
                  </motion.div>
                </div>
                
                {/* Background Glow */}
                <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[110%] h-[110%] bg-orange-100 rounded-full blur-[120px] -z-10 opacity-60"></div>
              </div>
            </motion.div>

          </div>
        </div>
      </section>



      {/* Banners */}
      <section className="container mx-auto px-4 mb-12">
        <div className="relative min-h-[160px] md:min-h-[200px]">
          {loading ? (
             <Skeleton className="w-full h-[160px] md:h-[200px] rounded-3xl" />
          ) : banners.length > 0 && (
            <AnimatePresence mode="wait">
              <motion.div
                key={bannerIndex}
                initial={{ opacity: 0, x: 40 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: -40 }}
                transition={{ duration: 0.3 }}
                className={`rounded-3xl p-6 md:p-10 bg-gradient-to-r ${banners[bannerIndex].gradient} text-primary-foreground relative overflow-hidden h-full`}
              >
                <div className="absolute top-0 right-0 w-64 h-64 bg-primary-foreground/5 rounded-full -translate-y-1/2 translate-x-1/3" />
                <div className="absolute bottom-0 left-0 w-32 h-32 bg-primary-foreground/5 rounded-full translate-y-1/2 -translate-x-1/3" />
                <div className="relative">
                  <p className="text-xs font-bold text-primary-foreground/60 tracking-widest uppercase mb-2">Limited Time Offer</p>
                  <p className="text-3xl md:text-4xl font-black">{banners[bannerIndex].title}</p>
                  <p className="text-primary-foreground/80 mt-2 text-sm md:text-base max-w-md">{banners[bannerIndex].subtitle}</p>
                  <p className="mt-4 text-sm font-mono bg-primary-foreground/20 inline-block px-4 py-2 rounded-xl backdrop-blur-sm font-bold tracking-wider">
                    {banners[bannerIndex].code}
                  </p>
                </div>
              </motion.div>
            </AnimatePresence>
          )}
          
          {!loading && banners.length > 1 && (
            <>
              <div className="absolute right-4 top-1/2 -translate-y-1/2 flex gap-2">
                <button onClick={() => setBannerIndex((i) => (i - 1 + banners.length) % banners.length)} className="w-9 h-9 rounded-full bg-primary-foreground/20 flex items-center justify-center hover:bg-primary-foreground/30 transition-colors">
                  <ChevronLeft className="w-4 h-4" />
                </button>
                <button onClick={() => setBannerIndex((i) => (i + 1) % banners.length)} className="w-9 h-9 rounded-full bg-primary-foreground/20 flex items-center justify-center hover:bg-primary-foreground/30 transition-colors">
                  <ChevronRight className="w-4 h-4" />
                </button>
              </div>
              <div className="flex justify-center gap-2 mt-5">
                {banners.map((_, i) => (
                  <button key={i} onClick={() => setBannerIndex(i)} className={`h-1.5 rounded-full transition-all duration-300 ${i === bannerIndex ? "bg-primary w-8" : "bg-muted-foreground/20 w-1.5"}`} />
                ))}
              </div>
            </>
          )}
        </div>
      </section>

      {/* Trending Section - Premium Upgrade */}
      <section className="container mx-auto px-4 mb-20 relative overflow-hidden">
        <div className="flex items-center justify-between mb-8">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl gradient-warm flex items-center justify-center shadow-lg">
              <TrendingUp className="w-5 h-5 text-primary-foreground" />
            </div>
            <div>
              <h2 className="text-2xl font-black text-foreground tracking-tight">Trending <span className="gradient-text italic">Now</span></h2>
              <p className="text-[10px] font-bold text-muted-foreground uppercase tracking-widest">Most loved in Coimbatore</p>
            </div>
          </div>
          <div className="flex gap-2">
            <button className="w-10 h-10 rounded-full border border-border flex items-center justify-center hover:bg-background hover:shadow-card transition-all">
              <ChevronLeft className="w-5 h-5 text-muted-foreground" />
            </button>
            <button className="w-10 h-10 rounded-full border border-border flex items-center justify-center hover:bg-background hover:shadow-card transition-all">
              <ChevronRight className="w-5 h-5 text-muted-foreground" />
            </button>
          </div>
        </div>
        <div className="flex gap-6 overflow-x-auto pb-8 scrollbar-hide snap-x -mx-4 px-4 sm:mx-0 sm:px-0">
          {trendingItems.map((t, i) => (
            <TrendingItem key={t.item.id} item={t.item} restaurantId={t.restaurantId} restaurantName={t.restaurantName} index={i} />
          ))}
        </div>
      </section>

      {/* What's on your mind? */}
      <section className="container mx-auto px-4 mb-20 relative">
        <div className="flex flex-col sm:flex-row items-center justify-between mb-10 gap-6">
          <div className="space-y-1">
            <h2 className="text-3xl font-black text-gray-900 tracking-tighter">What's on your <span className="text-primary">mind?</span></h2>
            <div className="w-12 h-1.5 gradient-primary rounded-full" />
          </div>
          
          <div className="flex items-center gap-3">
            <button
              onClick={() => { setVegOnly(!vegOnly); setNonVegOnly(false); }}
              className={`
                relative flex items-center gap-2.5 px-5 py-2.5 rounded-full text-sm font-bold transition-all duration-300 overflow-hidden group border
                ${vegOnly 
                  ? "bg-green-50 border-green-200 text-green-800 shadow-[0_4px_15px_rgba(34,197,94,0.2)]" 
                  : "bg-white border-gray-200 text-gray-600 shadow-sm hover:shadow-md hover:border-gray-300"
                }
              `}
            >
              {vegOnly && <div className="absolute inset-0 bg-green-500 opacity-10 animate-pulse"></div>}
              
              <div className={`w-3 h-3 rounded-sm border-[1.5px] relative flex items-center justify-center transition-colors ${vegOnly ? 'border-green-600' : 'border-gray-400 group-hover:border-green-500'}`}>
                <span className={`w-1.5 h-1.5 rounded-full transition-all duration-300 ${vegOnly ? 'bg-green-600 scale-100' : 'bg-transparent scale-0'}`} />
              </div>
              Veg Only
            </button>

            <button
              onClick={() => { setNonVegOnly(!nonVegOnly); setVegOnly(false); }}
              className={`
                relative flex items-center gap-2.5 px-5 py-2.5 rounded-full text-sm font-bold transition-all duration-300 overflow-hidden group border
                ${nonVegOnly 
                  ? "bg-red-50 border-red-200 text-red-800 shadow-[0_4px_15px_rgba(239,68,68,0.2)]" 
                  : "bg-white border-gray-200 text-gray-600 shadow-sm hover:shadow-md hover:border-gray-300"
                }
              `}
            >
              {nonVegOnly && <div className="absolute inset-0 bg-red-500 opacity-10 animate-pulse"></div>}
              
              <div className={`w-3 h-3 rounded-sm border-[1.5px] relative flex items-center justify-center transition-colors ${nonVegOnly ? 'border-red-600' : 'border-gray-400 group-hover:border-red-500'}`}>
                <span className={`w-1.5 h-1.5 rounded-full transition-all duration-300 ${nonVegOnly ? 'bg-red-600 scale-100' : 'bg-transparent scale-0'}`} />
              </div>
              Non Veg
            </button>
          </div>
        </div>

        {/* Categories Grid/Scroll Layout */}
        <div className="flex overflow-x-auto sm:grid sm:grid-cols-4 md:grid-cols-5 lg:grid-cols-8 xl:grid-cols-10 gap-5 sm:gap-6 pb-8 pt-4 px-2 -mx-2 hover:scroll-p-2 scrollbar-hide snap-x snap-mandatory scroll-smooth">
          {loading ? (
             Array.from({ length: 8 }).map((_, i) => (
               <Skeleton key={i} className="h-24 w-full rounded-2xl" />
             ))
          ) : categories.map((cat) => (
            <CategoryChip
              key={cat.id}
              category={cat}
              isActive={activeCategory === cat.name}
              onClick={() => setActiveCategory(activeCategory === cat.name ? null : cat.name)}
            />
          ))}
        </div>
      </section>

      {/* Restaurants */}
      <section className="container mx-auto px-4 pb-12">
        <div className="flex items-center justify-between mb-6">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-lg bg-primary/10 flex items-center justify-center">
              <Store className="w-4 h-4 text-primary" />
            </div>
            <h2 className="text-xl font-bold text-foreground">
              {activeCategory ? `${activeCategory} in Coimbatore` : searchQuery ? "Search Results" : "Top Picks in Coimbatore"}
            </h2>
          </div>
          <Link to="/restaurants" className="text-sm font-semibold text-primary hover:underline flex items-center gap-1 bg-primary/5 px-3 py-1.5 rounded-full hover:bg-primary/10 transition-colors">
            See all <ArrowRight className="w-3.5 h-3.5" />
          </Link>
        </div>
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-5">
          {loading ? (
            Array.from({ length: 8 }).map((_, i) => (
              <div key={i} className="space-y-3">
                <Skeleton className="h-48 w-full rounded-2xl" />
                <Skeleton className="h-6 w-3/4" />
                <Skeleton className="h-4 w-1/2" />
              </div>
            ))
          ) : error ? (
            <div className="col-span-full text-center py-20 px-4">
              <div className="max-w-md mx-auto bg-white p-8 rounded-[3rem] shadow-xl shadow-gray-100 border border-gray-100 flex flex-col items-center">
                <div className="w-16 h-16 bg-red-50 text-red-500 rounded-2xl flex items-center justify-center mb-6">
                  <RefreshCw className="w-8 h-8" />
                </div>
                <h3 className="text-xl font-black text-gray-900 mb-2">Connection Issues</h3>
                <p className="text-gray-500 mb-8 font-medium text-sm">
                  {error}
                </p>
                <button 
                  onClick={fetchData}
                  className="flex items-center gap-2 bg-gray-900 text-white px-8 py-4 rounded-2xl font-black hover:bg-black transition-all shadow-lg active:scale-95 uppercase tracking-widest text-xs"
                >
                  <RefreshCw className="w-4 h-4" />
                  Try Again
                </button>
              </div>
            </div>
          ) : (
            filteredRestaurants.map((restaurant, i) => (
              <RestaurantCard key={restaurant.id} restaurant={restaurant} index={i} />
            ))
          )}
        </div>
        {filteredRestaurants.length === 0 && (
          <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="text-center py-20">
            <p className="text-5xl mb-4">🍽️</p>
            <p className="text-lg font-semibold text-foreground">No restaurants found</p>
            <p className="text-sm text-muted-foreground mt-1">Try a different search or category</p>
          </motion.div>
        )}
      </section>

      {/* Testimonials */}

      {/* App CTA */}
      <section className="container mx-auto px-4 pb-12">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="gradient-primary rounded-3xl p-8 md:p-12 text-primary-foreground text-center relative overflow-hidden"
        >
          <div className="absolute top-0 right-0 w-96 h-96 bg-primary-foreground/5 rounded-full -translate-y-1/2 translate-x-1/3" />
          <div className="absolute bottom-0 left-0 w-64 h-64 bg-primary-foreground/5 rounded-full translate-y-1/2 -translate-x-1/3" />
          <div className="relative">
            <h3 className="text-2xl md:text-3xl font-black mb-2">Get ₹100 OFF Your First Order!</h3>
            <p className="text-primary-foreground/80 mb-6 max-w-md mx-auto">Use code <span className="font-mono font-bold bg-primary-foreground/20 px-2 py-0.5 rounded-lg">YUMORA100</span> at checkout</p>
            <Link
              to="/restaurants"
              className="inline-flex items-center gap-2 bg-primary-foreground text-primary font-bold px-8 py-3.5 rounded-2xl hover:opacity-90 transition-opacity shadow-elevated"
            >
              <Utensils className="w-4 h-4" /> Order Now
            </Link>
          </div>
        </motion.div>
      </section>

      <Footer />
    </div>
  );
};

export default Index;
