import { useState } from "react";
import { useCart } from "@/context/CartContext";
import { Link, useNavigate } from "react-router-dom";
import { ArrowLeft, CreditCard, Smartphone, Banknote, CheckCircle, Copy, QrCode, AlertCircle } from "lucide-react";
import Navbar from "@/components/Navbar";
import { toast } from "sonner";
import { toast as hotToast } from "react-hot-toast";
import { motion, AnimatePresence } from "framer-motion";
import { loadStripe } from "@stripe/stripe-js";
import { validateCardDetails } from "@/lib/paymentUtils";

const Checkout = () => {
  const { items, totalPrice, discount, placeOrder, error } = useCart();
  const navigate = useNavigate();
  const [orderPlaced, setOrderPlaced] = useState(false);
  const [orderId, setOrderId] = useState("");
  const [paymentMethod, setPaymentMethod] = useState("cod");
  const [showUPIDetails, setShowUPIDetails] = useState(false);
  const [processingPayment, setProcessingPayment] = useState(false);
  const [cardValidationErrors, setCardValidationErrors] = useState<Record<string, string>>({});
  const [cardDetails, setCardDetails] = useState({
    cardNumber: "",
    expiryDate: "",
    cvc: "",
    cardholderName: "",
  });
  const [address, setAddress] = useState({ name: "", phone: "", email: "", line1: "", line2: "", pincode: "" });

  const deliveryFee = totalPrice > 199 ? 0 : 30;
  const taxes = Math.round(totalPrice * 0.05);
  const grandTotal = Math.round(totalPrice - discount + deliveryFee + taxes);

  const playSuccessSound = () => {
    try {
      const AudioCtx = window.AudioContext || (window as any).webkitAudioContext;
      if (!AudioCtx) return;
      const audioContent = new AudioCtx();
      const oscillator = audioContent.createOscillator();
      const gainNode = audioContent.createGain();
      
      oscillator.type = 'sine';
      oscillator.frequency.setValueAtTime(880, audioContent.currentTime); // A5
      oscillator.frequency.exponentialRampToValueAtTime(1760, audioContent.currentTime + 0.1); // A6
      
      gainNode.gain.setValueAtTime(0.5, audioContent.currentTime);
      gainNode.gain.exponentialRampToValueAtTime(0.01, audioContent.currentTime + 0.3);
      
      oscillator.connect(gainNode);
      gainNode.connect(audioContent.destination);
      
      oscillator.start();
      oscillator.stop(audioContent.currentTime + 0.3);
    } catch (e) {
      console.error('Audio play failed', e);
    }
  };

  const showSuccessToast = (id: string, estimatedTime: string = "25-35 mins") => {
    hotToast.custom((t) => (
      <div
        className={`${
          t.visible ? "animate-in fade-in slide-in-from-top-4" : "animate-out fade-out slide-out-to-top-4"
        } bg-white border-2 border-green-500 shadow-2xl rounded-2xl p-5 w-full max-w-sm pointer-events-auto transform transition-all duration-300`}
      >
        <div className="flex items-start gap-4">
          <div className="bg-green-100 rounded-full p-2 flex-shrink-0">
            <span className="text-2xl block animate-bounce">🎉</span>
          </div>
          <div className="flex-1">
            <h3 className="font-bold text-green-700 text-lg mb-1">Order placed successfully!</h3>
            <p className="text-sm text-gray-500 mb-3">Your cravings are on the way.</p>
            <div className="bg-green-50 rounded-xl p-3 space-y-2 border border-green-100">
              <div className="flex justify-between items-center text-sm">
                <span className="text-green-700 font-medium">Order ID</span>
                <span className="font-bold font-mono text-green-900 bg-white px-2 py-1 rounded-md border border-green-200">#{id.substring(0, 8)}</span>
              </div>
              <div className="flex justify-between items-center text-sm">
                <span className="text-green-700 font-medium">Est. Delivery</span>
                <span className="font-bold text-green-700">{estimatedTime}</span>
              </div>
            </div>
          </div>
        </div>
      </div>
    ), {
      duration: 3000,
      position: "top-center",
    });
    
    playSuccessSound();
  };

  const onOrderSuccess = async (id: string) => {
    showSuccessToast(id);
    setOrderId(id);
    setOrderPlaced(true);
    localStorage.setItem("orderId", id);

    // Auto-start backend simulation immediately for testing
    try {
      await api.post(`/orders/track/${id}`);
    } catch (err) {
      console.log("Tracking start skipped or failed");
    }

    setTimeout(() => {
      navigate("/orders");
    }, 2000);
  };

  const copyUPI = () => {
    navigator.clipboard.writeText("kovai@upi");
    toast.success("UPI ID copied!");
  };

  const handlePayment = () => {
    window.location.href = `upi://pay?pa=yourupi@okaxis&pn=KovaiCrave&am=${grandTotal}&cu=INR`;
  };

  const handleRazorpay = async () => {
    if (!address.name || !address.phone || !address.email || !address.line1 || !address.pincode) {
      toast.error("Please fill in all required address fields");
      return;
    }

    setProcessingPayment(true);
    
    // 1. Load Razorpay Script
    const loadScript = (src: string) => {
      return new Promise((resolve) => {
        const script = document.createElement("script");
        script.src = src;
        script.onload = () => resolve(true);
        script.onerror = () => resolve(false);
        document.body.appendChild(script);
      });
    };

    const resScript = await loadScript("https://checkout.razorpay.com/v1/checkout.js");
    if (!resScript) {
      toast.error("Razorpay SDK failed to load. Are you online?");
      setProcessingPayment(false);
      return;
    }

    try {
      // 2. Create backend order
      const res = await api.post("/payment/create-order", {
        amount: grandTotal
      });

      const options = {
        key: "rzp_test_xxxxx", // same as .env
        amount: res.data.amount,
        currency: "INR",
        name: "KovaiCrave",
        description: "Food Delivery Payment",
        order_id: res.data.id,
        handler: async (response: any) => {
          // 3. Verify Payment on Backend
          try {
            const verifyRes = await api.post("/payment/verify", {
              razorpay_order_id: response.razorpay_order_id,
              razorpay_payment_id: response.razorpay_payment_id,
              razorpay_signature: response.razorpay_signature,
            });

            if (verifyRes.data.success) {
              toast.success("Payment Successful 🎉");
              const fullAddress = `${address.line1}, ${address.line2}, ${address.pincode}`;
              
              const orderData = {
                paymentMethod: "card",
                paymentId: response.razorpay_payment_id,
                paymentStatus: "Success",
                address: fullAddress,
                email: address.email,
                phone: address.phone,
                items: items,
                totalAmount: grandTotal
              };

              const newOrderId = await placeOrder("card", fullAddress, address.email, address.phone, {
                paymentId: response.razorpay_payment_id,
                paymentStatus: "Success"
              });
              if (newOrderId) {
                onOrderSuccess(newOrderId);
              }
            }
          } catch (err) {
            toast.error("Payment verification failed");
          }
        },
        prefill: {
          name: address.name,
          email: address.email,
          contact: address.phone,
        },
        theme: {
          color: "#f97316", // Brand orange
        },
      };

      const rzp = new (window as any).Razorpay(options);
      rzp.on('payment.failed', function (resp: any) {
        toast.error(`Payment failed: ${resp.error.description}`);
      });
      rzp.open();

    } catch (error: any) {
      toast.error(`Payment failed: ${error.message}`);
    } finally {
      setProcessingPayment(false);
    }
  };

  const handlePlaceOrder = async () => {
    if (!address.name || !address.phone || !address.email || !address.line1 || !address.pincode) {
      toast.error("Please fill in all required address fields");
      return;
    }

    if (paymentMethod === "card") {
      await handleRazorpay();
      return;
    }

    if (paymentMethod === "upi" && !showUPIDetails) {
      setShowUPIDetails(true);
      return;
    }

    const fullAddress = `${address.line1}, ${address.line2}, ${address.pincode}`;
    const newOrderId = await placeOrder(paymentMethod, fullAddress, address.email, address.phone);
    
    if (newOrderId) {
      onOrderSuccess(newOrderId);
    }
  };

  if (orderPlaced) {
    return (
      <div className="min-h-screen bg-background">
        <Navbar />
        <motion.div
          initial={{ opacity: 0, scale: 0.9 }}
          animate={{ opacity: 1, scale: 1 }}
          className="container mx-auto px-4 py-20 text-center max-w-md"
        >
          <motion.div
            initial={{ scale: 0 }}
            animate={{ scale: 1 }}
            transition={{ type: "spring", delay: 0.2 }}
          >
            <CheckCircle className="w-24 h-24 text-success mx-auto mb-6" />
          </motion.div>
          <h2 className="text-3xl font-black text-foreground mb-2">Order Placed! 🎉</h2>
          <p className="text-muted-foreground mb-2">Your food is being prepared and will arrive soon.</p>
          <p className="text-sm font-mono bg-secondary px-4 py-2 rounded-xl inline-block text-foreground font-bold mb-8">
            Order #{orderId}
          </p>
          <div className="flex flex-col gap-3 mb-8">
            <Link to="/orders" className="gradient-primary text-primary-foreground font-bold px-8 py-3.5 rounded-2xl shadow-elevated hover:opacity-90">
              Track Order
            </Link>
            <Link to="/" className="bg-secondary text-secondary-foreground font-bold px-8 py-3.5 rounded-2xl hover:bg-muted transition-colors">
              Back to Home
            </Link>
          </div>

          {/* Rapido Integration Section */}
          <motion.div 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.5 }}
            className="bg-yellow-50 border-2 border-yellow-400 rounded-3xl p-6 relative overflow-hidden text-left"
          >
            <div className="flex items-center gap-4 mb-4 relative z-10">
              <div className="bg-yellow-400 p-3 rounded-2xl shadow-sm">
                <Smartphone className="w-8 h-8 text-black" />
              </div>
              <div>
                <h4 className="font-bold text-black text-lg">Rapido Delivery</h4>
                <p className="text-xs text-yellow-800 font-semibold uppercase tracking-wider">Official Partner</p>
              </div>
            </div>

            <p className="text-sm text-yellow-900 mb-6 relative z-10">
              Your delivery is being handled by **Rapido**. Track your rider live or download the app for better updates.
            </p>

            <div className="flex flex-col gap-3 relative z-10">
              <a 
                href="rapido://" 
                className="w-full bg-black text-white font-bold py-3.5 rounded-2xl text-center shadow-lg hover:bg-gray-900 transition-all flex items-center justify-center gap-2"
                onClick={(e) => {
                  setTimeout(() => {
                    window.location.href = "https://play.google.com/store/apps/details?id=com.rapido.passenger";
                  }, 500);
                }}
              >
                <Smartphone className="w-5 h-5" /> Open Rapido App
              </a>
              
              <div className="grid grid-cols-2 gap-2 mt-2">
                <a 
                  href="https://play.google.com/store/apps/details?id=com.rapido.passenger" 
                  target="_blank"
                  className="bg-white/50 hover:bg-white text-black text-[10px] font-bold py-2 rounded-xl text-center border border-yellow-200 transition-colors"
                >
                   Android App
                </a>
                <a 
                  href="https://apps.apple.com/in/app/rapido-bike-taxi-auto-cabs/id1198463801" 
                  target="_blank"
                  className="bg-white/50 hover:bg-white text-black text-[10px] font-bold py-2 rounded-xl text-center border border-yellow-200 transition-colors"
                >
                   iOS App
                </a>
              </div>
            </div>

            {/* Decorative background element */}
            <div className="absolute -right-8 -bottom-8 w-32 h-32 bg-yellow-400 rounded-full opacity-20 blur-2xl" />
          </motion.div>
        </motion.div>
      </div>
    );
  }

  if (items.length === 0) {
    navigate("/cart");
    return null;
  }

  const paymentOptions = [
    { id: "cod", label: "Cash on Delivery", icon: Banknote, desc: "Pay when your food arrives" },
    { id: "upi", label: "UPI Payment", icon: Smartphone, desc: "GPay, PhonePe, Paytm" },
    { id: "card", label: "Credit/Debit Card", icon: CreditCard, desc: "Visa, Mastercard, RuPay" },
  ];

  return (
    <div className="min-h-screen bg-background pb-20 lg:pb-0">
      <Navbar />
      <div className="container mx-auto px-4 py-8 max-w-2xl">
        <Link to="/cart" className="inline-flex items-center gap-1 text-sm text-muted-foreground hover:text-foreground mb-6 transition-colors">
          <ArrowLeft className="w-4 h-4" /> Back to cart
        </Link>
        <h1 className="text-2xl font-bold text-foreground mb-6">Checkout</h1>

        {/* Address */}
        <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} className="bg-card rounded-2xl shadow-card p-5 mb-4">
          <h3 className="font-bold text-card-foreground mb-4">📍 Delivery Address</h3>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            {[
              { key: "name", label: "Full Name *", placeholder: "Your name" },
              { key: "phone", label: "Phone *", placeholder: "9876543210" },
              { key: "email", label: "Email *", placeholder: "your@email.com" },
              { key: "line1", label: "Address *", placeholder: "House/Flat, Street, Area", full: true },
              { key: "line2", label: "Landmark", placeholder: "Near..." },
              { key: "pincode", label: "Pincode *", placeholder: "641001" },
            ].map((f) => (
              <div key={f.key} className={(f as any).full ? "sm:col-span-2" : ""}>
                <label className="text-xs font-semibold text-muted-foreground mb-1.5 block">{f.label}</label>
                <input
                  value={address[f.key as keyof typeof address]}
                  onChange={(e) => setAddress({ ...address, [f.key]: e.target.value })}
                  placeholder={f.placeholder}
                  className="w-full px-4 py-3 bg-secondary rounded-xl text-sm outline-none focus:ring-2 focus:ring-primary/30 text-foreground placeholder:text-muted-foreground transition-all"
                />
              </div>
            ))}
          </div>
        </motion.div>

        {/* Payment */}
        <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.1 }} className="bg-card rounded-2xl shadow-card p-5 mb-4">
          <h3 className="font-bold text-card-foreground mb-4">💳 Payment Method</h3>
          <div className="space-y-2">
            {paymentOptions.map((opt) => (
              <button
                key={opt.id}
                onClick={() => { setPaymentMethod(opt.id); setShowUPIDetails(false); }}
                className={`w-full flex items-center gap-3 p-4 rounded-xl transition-all text-left ${
                  paymentMethod === opt.id ? "bg-primary/10 ring-2 ring-primary" : "bg-secondary hover:bg-muted"
                }`}
              >
                <opt.icon className={`w-5 h-5 ${paymentMethod === opt.id ? "text-primary" : "text-muted-foreground"}`} />
                <div>
                  <p className="text-sm font-semibold text-card-foreground">{opt.label}</p>
                  <p className="text-xs text-muted-foreground">{opt.desc}</p>
                </div>
              </button>
            ))}
          </div>

          {/* Card Payment Form */}
          <AnimatePresence>
            {paymentMethod === "card" && (
              <motion.div
                initial={{ opacity: 0, height: 0 }}
                animate={{ opacity: 1, height: "auto" }}
                exit={{ opacity: 0, height: 0 }}
                className="mt-4 overflow-hidden"
              >
                <div className="bg-secondary rounded-2xl p-5 space-y-4">
                  {Object.keys(cardValidationErrors).length > 0 && (
                    <motion.div
                      initial={{ opacity: 0 }}
                      animate={{ opacity: 1 }}
                      className="bg-destructive/10 text-destructive rounded-lg p-3 flex gap-2"
                    >
                      <AlertCircle className="w-5 h-5 flex-shrink-0 mt-0.5" />
                      <div className="space-y-1">
                        {Object.entries(cardValidationErrors).map(([key, error]) => (
                          <p key={key} className="text-xs font-medium">{error}</p>
                        ))}
                      </div>
                    </motion.div>
                  )}
                  <div>
                    <label className="text-xs font-semibold text-muted-foreground mb-1.5 block">Cardholder Name *</label>
                    <input
                      value={cardDetails.cardholderName}
                      onChange={(e) => setCardDetails({ ...cardDetails, cardholderName: e.target.value })}
                      placeholder="John Doe"
                      className={`w-full px-4 py-3 bg-card rounded-xl text-sm outline-none focus:ring-2 text-foreground placeholder:text-muted-foreground transition-all ${
                        cardValidationErrors.cardholderName ? "focus:ring-destructive/30 border border-destructive" : "focus:ring-primary/30"
                      }`}
                    />
                  </div>
                  <div>
                    <label className="text-xs font-semibold text-muted-foreground mb-1.5 block">Card Number *</label>
                    <input
                      value={cardDetails.cardNumber}
                      onChange={(e) => {
                        const value = e.target.value.replace(/\s/g, "");
                        const formatted = value.replace(/(\d{4})/g, "$1 ").trim();
                        setCardDetails({ ...cardDetails, cardNumber: formatted });
                        setCardValidationErrors({ ...cardValidationErrors, cardNumber: "" });
                      }}
                      placeholder="1234 5678 9012 3456"
                      maxLength={19}
                      className={`w-full px-4 py-3 bg-card rounded-xl text-sm outline-none focus:ring-2 text-foreground placeholder:text-muted-foreground transition-all font-mono ${
                        cardValidationErrors.cardNumber ? "focus:ring-destructive/30 border border-destructive" : "focus:ring-primary/30"
                      }`}
                    />
                  </div>
                  <div className="grid grid-cols-2 gap-3">
                    <div>
                      <label className="text-xs font-semibold text-muted-foreground mb-1.5 block">Expiry Date *</label>
                      <input
                        value={cardDetails.expiryDate}
                        onChange={(e) => {
                          let value = e.target.value.replace(/\D/g, "");
                          if (value.length >= 2) {
                            value = value.slice(0, 2) + "/" + value.slice(2, 4);
                          }
                          setCardDetails({ ...cardDetails, expiryDate: value });
                          setCardValidationErrors({ ...cardValidationErrors, expiryDate: "" });
                        }}
                        placeholder="MM/YY"
                        maxLength={5}
                        className={`w-full px-4 py-3 bg-card rounded-xl text-sm outline-none focus:ring-2 text-foreground placeholder:text-muted-foreground transition-all font-mono ${
                          cardValidationErrors.expiryDate ? "focus:ring-destructive/30 border border-destructive" : "focus:ring-primary/30"
                        }`}
                      />
                    </div>
                    <div>
                      <label className="text-xs font-semibold text-muted-foreground mb-1.5 block">CVV *</label>
                      <input
                        value={cardDetails.cvc}
                        onChange={(e) => {
                          setCardDetails({ ...cardDetails, cvc: e.target.value.replace(/\D/g, "").slice(0, 3) });
                          setCardValidationErrors({ ...cardValidationErrors, cvc: "" });
                        }}
                        placeholder="123"
                        maxLength={3}
                        type="password"
                        className={`w-full px-4 py-3 bg-card rounded-xl text-sm outline-none focus:ring-2 text-foreground placeholder:text-muted-foreground transition-all font-mono ${
                          cardValidationErrors.cvc ? "focus:ring-destructive/30 border border-destructive" : "focus:ring-primary/30"
                        }`}
                      />
                    </div>
                  </div>
                  <div className="bg-primary/10 text-primary rounded-lg p-3 text-xs flex gap-2">
                    <span>ℹ️</span>
                    <p>Demo: Use test card <strong>4242 4242 4242 4242</strong>, any future date, any CVC</p>
                  </div>
                </div>
              </motion.div>
            )}
          </AnimatePresence>

          {/* UPI Details */}
          <AnimatePresence>
            {paymentMethod === "upi" && showUPIDetails && (
              <motion.div
                initial={{ opacity: 0, height: 0 }}
                animate={{ opacity: 1, height: "auto" }}
                exit={{ opacity: 0, height: 0 }}
                className="mt-4 overflow-hidden"
              >
                <div className="bg-secondary rounded-2xl p-5 text-center">
                  <h4 className="font-bold text-foreground mb-3">Pay via UPI</h4>
                  {/* QR Placeholder */}
                  <div className="w-48 h-48 mx-auto bg-card rounded-2xl flex flex-col items-center justify-center shadow-card mb-4">
                    <QrCode className="w-24 h-24 text-foreground/70" />
                    <p className="text-xs text-muted-foreground mt-2">Scan to pay</p>
                  </div>
                  <p className="text-sm text-muted-foreground mb-1">UPI ID:</p>
                  <div className="flex items-center justify-center gap-2 mb-4">
                    <span className="font-mono font-bold text-lg text-foreground bg-card px-4 py-2 rounded-xl">kovai@upi</span>
                    <button onClick={copyUPI} className="w-9 h-9 flex items-center justify-center rounded-xl bg-primary/10 text-primary hover:bg-primary/20 transition-colors">
                      <Copy className="w-4 h-4" />
                    </button>
                  </div>
                  <p className="text-xs text-muted-foreground mb-4">Amount: ₹{grandTotal}</p>
                  <div className="flex flex-col gap-2">
                    <button
                      onClick={handlePayment}
                      className="w-full bg-[#1A73E8] text-white font-bold py-3.5 rounded-2xl shadow-elevated hover:opacity-90 transition-opacity"
                    >
                      📱 Pay with UPI App
                    </button>
                    <button
                      onClick={handlePlaceOrder}
                      className="w-full bg-secondary text-secondary-foreground font-bold py-3.5 rounded-2xl hover:bg-muted transition-colors"
                    >
                      ✅ I have already paid
                    </button>
                  </div>
                </div>
              </motion.div>
            )}
          </AnimatePresence>
        </motion.div>

        {/* Summary */}
        <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.2 }} className="bg-card rounded-2xl shadow-card p-5 mb-6">
          <h3 className="font-bold text-card-foreground mb-3">🧾 Order Summary</h3>
          {items.map((item) => (
            <div key={item.id} className="flex justify-between text-sm py-1.5 text-muted-foreground">
              <span className="flex items-center gap-2">
                <span className={item.isVeg ? "veg-dot !w-3 !h-3" : "nonveg-dot !w-3 !h-3"} />
                {item.name} × {item.quantity}
              </span>
              <span>₹{item.price * item.quantity}</span>
            </div>
          ))}
          <div className="border-t border-border mt-3 pt-3 flex justify-between font-bold text-foreground text-lg">
            <span>Total</span><span>₹{grandTotal}</span>
          </div>
        </motion.div>

        {error && (
          <motion.div 
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            className="mb-4 p-4 bg-red-50 text-red-600 rounded-2xl border border-red-100 flex items-center gap-3 shadow-sm"
          >
            <AlertCircle className="w-5 h-5 shrink-0" />
            <div className="flex-1">
              <p className="text-xs font-black uppercase tracking-widest leading-none mb-1">Payment/Order Error</p>
              <p className="text-xs font-bold leading-tight">{error}</p>
            </div>
          </motion.div>
        )}

        {!(paymentMethod === "upi" && showUPIDetails) && !(paymentMethod === "card") && (
          <button
            onClick={handlePlaceOrder}
            className="w-full gradient-primary text-primary-foreground font-bold py-4 rounded-2xl shadow-elevated hover:opacity-90 transition-opacity text-lg disabled:opacity-50 disabled:cursor-not-allowed"
            disabled={processingPayment}
          >
            {paymentMethod === "cod" ? "Confirm Order — ₹" : "Pay via UPI — ₹"}{grandTotal}
          </button>
        )}
        
        {paymentMethod === "card" && (
          <button
            onClick={handlePlaceOrder}
            className="w-full gradient-primary text-primary-foreground font-bold py-4 rounded-2xl shadow-elevated hover:opacity-90 transition-opacity text-lg disabled:opacity-50 disabled:cursor-not-allowed"
            disabled={processingPayment}
          >
            {processingPayment ? "Processing..." : `Pay Now 💳`}
          </button>
        )}
      </div>
    </div>
  );
};

export default Checkout;
